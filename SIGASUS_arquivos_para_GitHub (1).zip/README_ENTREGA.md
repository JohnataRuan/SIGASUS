# SIGASUS — Entrega de Modelagem de Casos de Uso

Disciplina: Projeto Integrador e Prática Profissional II — UEPB.
Professor: Thiago Soares Marques.

## Arquivos para adicionar ao repositório existente

Copie **somente a pasta `docs/`** para a raiz do repositório `JohnataRuan/SIGASUS`.
Não substitua os arquivos `README.md` e `ESPECIFICAÇÕES.md` que já existem.

- `docs/especificacao_casos_uso_SIGASUS.docx` — documento oficial fornecido pela equipe
- `docs/diagrama_casos_uso.png` — exportação do diagrama
- `docs/diagrama_casos_uso.svg` — versão vetorial editável
- `docs/diagrama_casos_uso.dot` — fonte editável Graphviz

**Atenção:** a documentação é referente ao desenvolvimento planejado em Java; este pacote não inclui código-fonte Java, pois não foi fornecido.
